#' Free Parameters in Configural Invariance Model
#'
#' Calculates the number of free parameters in a model assuming configural measurement invariance (equal factor structure and equal loading patterns) across groups.
#' It is assumed that there are no cross-loadings, correlated item residuals, or uncorrelated factors.
#' @param nIndicators Number of indicators in model
#' @param nFactors Number of factors in model
#' @param nGroups Number of groups
#'
#' @return Number of free parameters
#' @export
#'
#' @examples
#' npar.configuralInvariance(nIndicators = 6, nFactors = 2, nGroups = 2)
npar.configuralInvariance <- function(nIndicators, nFactors, nGroups){

  npar <- sum(c(
    # loadings
    nIndicators * nGroups,

    # residual variances
    nIndicators * nGroups,

    # factor correlations
    nFactors*(nFactors-1)/2 * nGroups

    # no factor variances
  ))

  return(npar)

}
