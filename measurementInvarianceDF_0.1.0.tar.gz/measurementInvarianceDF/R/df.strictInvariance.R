#' Degress of Freedom in Strict Invariance Model
#'
#' Calculates the degrees of freedom in a model assuming strict measurement invariance (equal unstandardized factor loadings, equal item intercepts, equal item residual variances) across groups.
#' It is assumed that there are no cross-loadings, correlated item residuals, or uncorrelated factors.
#' @param nIndicators Number of indicators in model
#' @param nFactors Number of factors in model
#' @param nGroups Number of groups
#'
#' @return Number of free parameters
#' @export
#'
#' @examples
#' df.strictInvariance(nIndicators = 6, nFactors = 2, nGroups = 2)

df.strictInvariance <- function(nIndicators, nFactors, nGroups){

  # unique information
  information <- ((nIndicators*(nIndicators + 3))/2)*nGroups

  # free parameters
  npar <- npar.strictInvariance(nIndicators, nFactors, nGroups)

  # degrees of freedom
  df <- information - npar

  return(df)

}
